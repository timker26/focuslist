import { dateKey, startOfDay } from "./date-utils";
import type { Task } from "@/lib/tasks-context";

const WEEKDAYS = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"];

export type WeeklyCompletion = {
  key: string;
  label: string;
  dayNumber: number;
  count: number;
};

export function getWeeklyCompletions(tasks: Task[], reference = new Date()): WeeklyCompletion[] {
  const today = startOfDay(reference);
  const days = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(today);
    date.setDate(today.getDate() - 6 + index);
    return date;
  });
  const counts = new Map<string, number>();
  for (const task of tasks) {
    const completion = task.archivedAt ?? task.completedAt;
    if (!completion) continue;
    const key = dateKey(completion);
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  return days.map((date) => ({ key: dateKey(date), label: WEEKDAYS[date.getDay()], dayNumber: date.getDate(), count: counts.get(dateKey(date)) ?? 0 }));
}

export function getWeeklySummary(completions: WeeklyCompletion[]) {
  const total = completions.reduce((sum, day) => sum + day.count, 0);
  const best = completions.reduce((bestDay, day) => day.count > bestDay.count ? day : bestDay, completions[0]);
  return { total, best };
}
