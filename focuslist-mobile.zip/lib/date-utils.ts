export function startOfDay(value: Date) {
  return new Date(value.getFullYear(), value.getMonth(), value.getDate());
}

export function dateKey(value: Date | string) {
  const date = typeof value === "string" ? new Date(value) : value;
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export function isSameDay(left: Date | string, right: Date | string) {
  return dateKey(left) === dateKey(right);
}

export function isOverdue(iso?: string) {
  return Boolean(iso && startOfDay(new Date(iso)).getTime() < startOfDay(new Date()).getTime());
}

export function formatDueDate(iso?: string) {
  if (!iso) return "Без срока";
  const date = new Date(iso);
  const today = new Date();
  const tomorrow = new Date();
  tomorrow.setDate(today.getDate() + 1);
  if (isSameDay(date, today)) return "Сегодня";
  if (isSameDay(date, tomorrow)) return "Завтра";
  return new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short" }).format(date);
}

export function formatDateInput(iso?: string) {
  if (!iso) return "";
  const date = new Date(iso);
  return `${String(date.getDate()).padStart(2, "0")}.${String(date.getMonth() + 1).padStart(2, "0")}.${date.getFullYear()}`;
}

export function parseDateInput(value: string) {
  const match = value.trim().match(/^(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})$/);
  if (!match) return undefined;
  const [, dayRaw, monthRaw, yearRaw] = match;
  const date = new Date(Number(yearRaw), Number(monthRaw) - 1, Number(dayRaw), 9, 0, 0, 0);
  if (date.getFullYear() !== Number(yearRaw) || date.getMonth() !== Number(monthRaw) - 1 || date.getDate() !== Number(dayRaw)) return undefined;
  return date.toISOString();
}

export function formatTimeInput(iso?: string) {
  if (!iso) return "";
  const date = new Date(iso);
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

export function parseDateTimeInput(dateValue: string, timeValue: string) {
  const dateMatch = dateValue.trim().match(/^(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})$/);
  const timeMatch = (timeValue.trim() || "09:00").match(/^(\d{1,2}):(\d{2})$/);
  if (!dateMatch || !timeMatch) return undefined;
  const [, dayRaw, monthRaw, yearRaw] = dateMatch;
  const [, hourRaw, minuteRaw] = timeMatch;
  const date = new Date(Number(yearRaw), Number(monthRaw) - 1, Number(dayRaw), Number(hourRaw), Number(minuteRaw), 0, 0);
  if (date.getFullYear() !== Number(yearRaw) || date.getMonth() !== Number(monthRaw) - 1 || date.getDate() !== Number(dayRaw) || date.getHours() !== Number(hourRaw) || date.getMinutes() !== Number(minuteRaw)) return undefined;
  return date.toISOString();
}

export function nextRecurringDueAt(dueAt: string | undefined, recurrence: "daily" | "weekly") {
  const next = dueAt ? new Date(dueAt) : new Date();
  next.setDate(next.getDate() + (recurrence === "daily" ? 1 : 7));
  return next.toISOString();
}

export function addDays(offset: number) {
  const date = new Date();
  date.setHours(9, 0, 0, 0);
  date.setDate(date.getDate() + offset);
  return date.toISOString();
}
