import type { TaskFolder } from "./tasks-context";

export const starterFolderTemplates: TaskFolder[] = [
  { id: "starter-home", title: "Дом", color: "#2EAD75", icon: "home", emoji: "🏠", isPinned: false, coverId: "forest", templates: [], createdAt: "2026-01-01T00:00:00.000Z" },
  { id: "starter-car", title: "Авто", color: "#E89642", icon: "directions-car", emoji: "🚗", isPinned: false, coverId: "sunset", templates: [], createdAt: "2026-01-01T00:00:00.000Z" },
  { id: "starter-work", title: "Работа", color: "#4659E8", icon: "work", emoji: "💼", isPinned: false, coverId: "ocean", templates: [], createdAt: "2026-01-01T00:00:00.000Z" },
  { id: "starter-personal", title: "Личное", color: "#9A55DE", icon: "person", emoji: "✨", isPinned: false, coverId: "violet", templates: [], createdAt: "2026-01-01T00:00:00.000Z" },
];

export function mergeStarterFolders(folders: TaskFolder[], shouldAddStarterFolders: boolean) {
  if (!shouldAddStarterFolders) return folders;
  const existingTitles = new Set(folders.map((folder) => folder.title.trim().toLocaleLowerCase("ru-RU")));
  return [...folders, ...starterFolderTemplates.filter((folder) => !existingTitles.has(folder.title.toLocaleLowerCase("ru-RU")))];
}
